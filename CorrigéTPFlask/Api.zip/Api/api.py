from flask import Flask, Response, make_response, jsonify, request
from flask.json import loads

from Api.Model.Model import Model
from Api.utils import article_to_dict, dict_to_article


app = Flask(__name__)


@app.route('/article/<int:id>', methods=['GET'])
def lire_article(id: int):
    try:
        a = Model.get_instance().rechercher_article_par_id(id)

        return make_response(
            jsonify(
                article_to_dict(a)
            ),
            200
        )
    except Exception as e:
        message = {"message": e.__str__()}
        return make_response(jsonify(message), 404)


@app.route('/articles', methods=['GET'])
def rechercher_tous_les_article() -> Response:
    les_articles = Model.get_instance().rechercher_tous_les_articles()

    liste = []
    for a in les_articles:
        liste.append(article_to_dict(a))

    return make_response(
        jsonify(liste)
    )


@app.route('/article', methods=['POST'])
def ajouter_article():
    try:
        data = request.data
        article = dict_to_article(loads(data))
        id_insere = Model.get_instance().ajouter_article(article)

        message = {"message": f"id inséré {id_insere}"}
        return make_response(jsonify(message), 200)
    except Exception as e:
        message = {"message": e.__str__()}
        return make_response(jsonify(message), 400)


if __name__ == '__main__':
    app.run(port=8080, debug=True)
