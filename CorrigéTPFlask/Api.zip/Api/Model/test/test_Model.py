import unittest

from Api.Model.Article import Article
from Api.Model.Model import Model


class MyTestCase(unittest.TestCase):

    model = None

    def setUp(self) -> None:
        self.model = Model.get_instance()

    def test_rechercher_tous_les_articles(self) -> None:
        liste_article = self.model.rechercher_tous_les_articles()
        for article in liste_article:
            if article.id == 1:
                self.assertEqual("Robert DUPONT", article.auteur)
            if article.id == 2:
                self.assertEqual("Etienne LANGLET", article.auteur)

    def test_rechercher_article_par_id(self) -> None:
        article = self.model.rechercher_article_par_id(1)
        self.assertEqual(1, article.id)
        article = self.model.rechercher_article_par_id(2)
        self.assertEqual(2, article.id)

    def test_ajouter_article(self) -> None:
        article = Article(99, "Article de test", "Test TEST", "Texte de test")
        id_genere = self.model.ajouter_article(article)
        self.assertEqual(3, id_genere)
        article_recupere = self.model.rechercher_article_par_id(3)
        self.assertEqual("Article de test", article_recupere.titre)
        self.assertEqual("Test TEST", article_recupere.auteur)
        self.assertEqual("Texte de test", article_recupere.texte)


if __name__ == '__main__':
    unittest.main()
