from Api.Model.Article import Article


def dict_to_article(dico: dict) -> Article:
    return Article(
        dico['id'],
        dico['titre'],
        dico['auteur'],
        dico['texte']
    )


def article_to_dict(article: Article) -> dict:
    return {
        'id': article.id,
        'titre': article.titre,
        'auteur': article.auteur,
        'texte': article.texte
    }